const { Configuration, OpenAIApi } = require("openai");

module.exports = async (req, res) => {
  const { letter, count } = req.body;
  const config = new Configuration({ apiKey: process.env.OPENAI_API_KEY });
  const openai = new OpenAIApi(config);

  try {
    const prompt = `Generate ${count} alliterative three-word phrases. Each word must start with '${letter}'. 
The first word should be a cheeky or upbeat adjective. 
The second should be a North American office furniture term, preferably associated with MillerKnoll (no Steelcase, Haworth, Teknion, Allsteel). 
The third should be a fun or energetic noun. 
Return as a list.`;

    const completion = await openai.createChatCompletion({
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.9
    });

    const phrases = completion.data.choices[0].message.content
      .split("
")
      .filter(line => line.trim())
      .map(line => line.replace(/^[0-9.\-\)]*\s*/, ''));

    res.status(200).json({ phrases });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};