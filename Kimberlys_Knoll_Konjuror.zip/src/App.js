import React, { useState } from 'react';

export default function App() {
  const [letter, setLetter] = useState('');
  const [count, setCount] = useState(2);
  const [results, setResults] = useState([]);

  const generate = async () => {
    if (!letter || count < 1) {
      alert("Please enter a valid letter and quantity.");
      return;
    }

    const res = await fetch('/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ letter, count })
    });
    const data = await res.json();
    setResults(data.phrases || []);
  };

  return (
    <div style={{ padding: 40, fontFamily: 'Arial, sans-serif', textAlign: 'center' }}>
      <img src="/logo.png" alt="Goodmans Logo" style={{ maxWidth: 200 }} />
      <h1>Kimberly's Knoll Konjuror</h1>
      <p>Enter a letter and number of phrases to conjure furniture-flavored alliteration.</p>
      <div style={{ marginBottom: 20 }}>
        <input placeholder="Letter" maxLength="1" onChange={(e) => setLetter(e.target.value.toLowerCase())} />
        <input type="number" value={count} min={1} max={10} onChange={(e) => setCount(Number(e.target.value))} style={{ marginLeft: 10 }} />
        <button onClick={generate} style={{ marginLeft: 10 }}>Generate</button>
      </div>
      <div>
        {results.map((phrase, i) => (
          <div key={i} style={{ fontSize: '1.2em', margin: '8px 0' }}>{phrase}</div>
        ))}
      </div>
    </div>
  );
}